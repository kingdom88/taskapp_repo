# PHP Task management tool By Kingdom Lwandle



## Info
This is a task/todo list written in PHP.  
It uses a JSON text file for the tasks, and the visual side is created with the HTML5 Kickstart framework by Joshua Gatcke.


## Install

Download and Unzip the file and upload to the web-directory (public_html, /var/www/, /srv/httpd etc..) and make sure that the webserver can write to the json file (chown www-data:www-data task.json or chmow 777 task.json).

###Benefits of using php and Json together.

- No ads
- Nobody selling your data
- Nobody monitoring your activity
- Data is easy to get out (no vendor lock-in) and to backup.
- Offline mode? Host it on your local machine with a LAMP/WAMP/MAMP server.

## Features
- Add/Close/Cancel/Update tasks
- Due date on tasks, time left/late shown.
- No database required



