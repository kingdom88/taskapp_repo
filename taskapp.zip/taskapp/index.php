<!DOCTYPE html>
<html>
<head>
	<title>Task Management tool</title>
	
	<style>

.modal {
    display: none; 
    position: fixed; 
    z-index: 1; 
    padding-top: 100px; 
    left: 0;
    top: 0;
    width: 100%; 
    height: 100%; 
    overflow: auto; 
    background-color: 
    background-color: 
}


.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 65%;
}


.close {
    color: #aaaaaa;
    float: right;
    font-size: 50px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>
</head>

<?php


include("header.php");
echo "<button id=\"myBtn\">ADD</button>";


echo "<ul class=\"tabs left\">";
echo "<li><a href=\"#opentab\">".$LANG["open"]."</a></li>";
echo "<li><a href=\"#closedtab\">".$LANG["close"]."</a></li>";
echo "<li><a href=\"#cancelledtab\">".$LANG["cancel"]."</a></li>";
echo "</ul>";

echo"<div id=\"myModal\" class=\"modal\">";
echo"<div class=\"modal-content\">";
echo"<span class=\"close\">&times;</span>";

echo "<center><h2>".$LANG["addtask"]."</h2></center>";

echo "<p>";

showinputform("action.php");

echo "</p>";

echo "</div>";
echo "</div>";

echo "<p>";

echo "<div class=\"tab-content\" id=\"opentab\">";
echo "<center><h2>".$LANG["open"]."</h2></center>";
listtasks($json_a,"open","table");

echo "</p>";


echo "</div> <!-- tab div -->";



echo "<div class=\"tab-content\" id=\"closedtab\">";

echo "<center><h2>".$LANG["close"]."</h2></center>";
	listtasks($json_a,"closed","table");

echo "</div> <!-- tab div -->";

echo "<div class=\"tab-content\" id=\"cancelledtab\">";
echo "<center><h2>".$LANG["cancel"]."</h2></center>";

listtasks($json_a,"deleted","table");

echo "</div> <!-- tab div -->";

echo "</div><!--col_12 -->";

echo "<div class=\"col_6\">";

echo "<p>".$LANG["infotext"]."</p>";

echo "</div> <!-- col_ -->";


include("footer.php");
?>
<body>
	<script>

var modal = document.getElementById('myModal');


var btn = document.getElementById("myBtn");


var span = document.getElementsByClassName("close")[0];


btn.onclick = function() {
    modal.style.display = "block";
}


span.onclick = function() {
    modal.style.display = "none";
}


window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</body>
</html>